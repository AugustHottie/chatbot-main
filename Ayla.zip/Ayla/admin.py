from django.contrib import admin

from Ayla.models import Chatbot

# Register your models here.

admin.site.register(Chatbot)
